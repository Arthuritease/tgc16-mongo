[
  {
    clinic_id: 304,
    address: {
      street: "Yishun Ring road",
      block: "456",
      unit: "01-068",
      Postal: "755456",
    },
  },
  {
    clinic_id: 301,
    address: {
      street: "Canberra Drive",
      block: "130",
      unit: "01-069",
      Postal: "731130",
    },
  },
];
