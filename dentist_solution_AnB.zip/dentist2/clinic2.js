[
  {
    clinic_id: 304,
    address: {
      street: "Yishun Ring road",
      block: "456",
      unit: "01-068",
      Postal: "755456",
    },
    appointments: [
      {
        appt_id: 201,
        patient: {
          patient_id: 001,
          name: "Tan Ah Kow",
          DOB: "1994-02-02",
          address: {
            street: "Woodlands Drive 72",
            block: "888",
            unit: "08-188",
            Postal: "730888",
          },
        },
        dentist: {
          dentst_id: 101,
          name: "Dr Tan Ah Mao",
        },
        treatments:"Crowning"
      },
    
    ],
  },
];
